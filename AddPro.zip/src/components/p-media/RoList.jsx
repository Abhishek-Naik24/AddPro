import React from 'react'

const RoList = () => {
    return (
        <div>
            <h5>PRESS-MEDIA RO LIST</h5>
            <div className="bg-light">
                <div class="row mb-3">
                    <div className="col-lg-3">
                        <label class="col-form-label">STATUS</label>
                        <div class="">
                            <select class="w-100 p-1">
                                <option selected>All</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-lg-3">
                        <label class="col-form-label">PAPER</label>
                        <div class="">
                            <select class="w-100 p-1" aria-label="Default select example">
                                <option selected>Select</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-lg-3">
                        <label class="col-form-label">CLIENT</label>
                        <div class="">
                            <select class="w-100 p-1" aria-label="Default select example">
                                <option selected>Select</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-lg-3">
                        <label class="col-form-label">PAY STATUS</label>
                        <div class="">
                            <select class="w-100 p-1" aria-label="Default select example">
                                <option selected>All</option>
                                <option value="1">One</option>
                                <option value="2">Two</option>
                                <option value="3">Three</option>
                            </select>
                        </div>
                    </div>
                    <div className="col-lg-3 mt-1">
                        <label class="col-form-label">FROM DATE</label>
                        <div class="">
                            <div class="w-100 p-1">
                                <input type="date" class="form-control" aria-label="Default select example" />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 mt-1">
                        <label class="col-form-label">FROM DATE</label>
                        <div class="">
                            <div class="w-100 p-1">
                                <input type="date" class="form-control" aria-label="Default select example" />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 mt-1">
                        <label class="col-form-label">SEARCH RO/INVOICE No</label>
                        <div class="">
                            <div class="w-75 p-1">
                                <input type="text" class="form-control" aria-label="Default select example" />
                            </div>
                        </div>
                    </div>
                    <div className="col-lg-3 mt-1 d-flex justify-content-end align-item-center">
                        <button className='btn'>SHOW</button>
                        <button className='btn'>RESET</button>
                        <button className='btn'>ADD NEW RO</button>
                    </div>
                </div>
            </div>
        </div>
    )
}

export default RoList